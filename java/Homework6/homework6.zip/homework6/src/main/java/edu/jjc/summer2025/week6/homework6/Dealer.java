package main.java.edu.jjc.summer2025.week6.homework6;// Dealer.java
// Author: Wayne Mitchell
// Program 5 - Dealer class for CIS 261
// Description

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Dealer {

    public static void main(String[] args) {

        // create Arraylist of cars and call it inventory
        ArrayList<Car> inventory = new ArrayList<>();

        Scanner input = new Scanner(System.in);
        int choice;

        System.out.println("Welcome to the JJC Car Dealership Inventory Program\n");

        do {
            displayMenu();
            choice = input.nextInt();
            input.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addData(inventory);
                    break;
                case 2:
                    deleteData(inventory);
                    break;
                case 3:
                    printData(inventory);
                    break;
                case 4:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 4);

        input.close();
    }

    // Displays the menu
    public static void displayMenu() {
    // complete this method
        System.out.println("Menu:");
        System.out.println("1. Add Car");
        System.out.println("2. Delete Car");
        System.out.println("3. Print Inventory");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    // Adds a car to the inventory
    public static void addData(ArrayList<Car> cars) {
    // complete this method
        Scanner input = new Scanner(System.in);
        System.out.print("Enter car make: ");
        String make = input.nextLine();
        System.out.print("Enter car price: ");
        int price = input.nextInt();
        cars.add(new Car(make, price));
        System.out.println("Car added successfully.");
    }
    
    

    // Deletes a car from the inventory
    public static void deleteData(ArrayList<Car> cars) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the index of the car to delete (0-" + (cars.size() - 1) + "): ");
        int index = input.nextInt();
        if (index >= 0 && index < cars.size()) {
            cars.remove(index);
            System.out.println("Car deleted successfully.");
        } else {
            System.out.println("Invalid index.");
        }
    }

    // Prints the inventory
    public static void printData(ArrayList<Car> cars) {
    // complete this method
        if (cars.isEmpty()) {
            System.out.println("Inventory is empty.");
            return;
        }
        for (Car c : cars) {
            System.out.println("Make: " + c.getMake() + ", Price: " + NumberFormat.getCurrencyInstance().format(c.getPrice()));
        }

        System.out.println();
    }
}
