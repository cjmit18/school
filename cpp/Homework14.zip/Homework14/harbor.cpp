#include "Boat.h"
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>

int main(){
    std::srand(static_cast<unsigned int>(std::time(0)));

    std::cout << "\tBoat\tLength\tOars/Cabins" << std::endl;
    std::cout << "\t====\t======\t===========" << std::endl;
    Boat boat(0.0f);
    std::cout << boat.getLength() << std::endl;
    return 0;
/*     for (int i = 0; i < 20; i++) {
        int coinflip = std::rand() % 2;
            if (coinflip == 0){
                Yaht yShip(i*1.23+500, std::rand() % 1);
                std::cout << yShip.toString() << std::endl;
            }
            if (coinflip == 1) {
                Rowboat rBoat(i+1.23+500,i+1);
                std::cout << rBoat.toString() << std::endl;
            }
    } 
 */

};