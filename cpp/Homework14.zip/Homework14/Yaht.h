
#ifndef YAHT_H
#define YAHT_H
#include <string>
#include "Boat.h"
class Yaht : public Boat {
    private:
        int cabins;
    public:
    Yaht(float length, int numCabins) : Boat(length) {
        cabins = numCabins;
    }
    void setCabins(int);
    int getCabins() const;
    std::string toString() const;
};
#endif