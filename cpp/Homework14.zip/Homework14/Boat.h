#ifndef BOAT_H
#define BOAT_H
#include <string>

class Boat {
    private:
        float length;
    public:
    Boat(float len);

    void setLength(float);
    float getLength() const;
    std::string toString() const;

};
#endif