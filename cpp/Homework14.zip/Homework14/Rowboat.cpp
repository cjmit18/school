#include "Rowboat.h"
#include <sstream>
#include <iomanip>

void Rowboat::setOars(int numOars) {
    oars = numOars;
}
int Rowboat::getOars() const {
    return oars;
}
std::string Rowboat::toString() const {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output << "Rowboat with " << getOars() << " oars";
    return output.str();
}