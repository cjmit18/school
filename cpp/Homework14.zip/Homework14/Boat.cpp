#include "Boat.h"
#include <sstream>
#include <iomanip>

Boat::Boat(float len) : length(len) {

}

void Boat::setLength(float len) {
    length = len;
}
float Boat::getLength() const {
    return length;
}

std::string Boat::toString() const {
std::ostringstream output;
output << std::fixed << std::setprecision(2);
output << "Boat length: " << getLength();
return output.str();
}