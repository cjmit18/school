#include "yaht.h"
#include <sstream>
#include <iomanip>

void Yaht::setCabins(int numCabins) {
    cabins = numCabins;
}
int Yaht::getCabins() const {
    return cabins;
}
std::string Yaht::toString() const {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output << "Yaht with " << getCabins() << " cabins";
    return output.str();
}