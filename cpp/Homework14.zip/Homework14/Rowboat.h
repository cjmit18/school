#ifndef ROWBOAT_H
#define ROWBOAT_H

#include <string>
#include "Boat.h"

class Rowboat : public Boat {
    private:
        int oars;

    public:
    Rowboat(float len, int numOfOar) : Boat(len) {
        oars = numOfOar;
    }
    
    void setOars(int);
    int getOars() const;
    std::string toString() const;
};
#endif