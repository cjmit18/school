/*
 * Product Class Header File
 * CIS 246 - Homework 5
 * This class represents a product with price and total sales tracking
 */

class Product {
    private:
        // Data members with in-class initializers
        double price = 0.0;      // Product price in dollars
        double totalSales = 0.0; // Total sales for the product in dollars
        
    public:
        // Constructor using member initializer list
        Product(double p) : price(p) {
            // Body is empty as required
        }

        // Getter for price
        double getPrice() const {
            return price;
        }

        // Setter for price
        void setPrice(double p) {
            price = p;
        }
        
        // Getter for totalSales
        double getTotalSales() const {
            return totalSales;
        }
        
        // Setter for totalSales
        void setTotalSales(double sales) {
            totalSales = sales;
        }

        // Function to update total sales based on quantity sold
        void updateTotalSales(int quantity) {
            // Compute total value of current sale
            double saleValue = quantity * getPrice();
            
            // Update totalSales by adding current sale to existing total
            setTotalSales(getTotalSales() + saleValue);
        }
};