/* Wayne Mitchell
*  CIS 256
* Homework 7 - Rock, Paper, Scissors
*/ 
#include <iostream>
#include <string>
#include "Player.H"


int main() {
    
    std::cout << "Welcome to Rock, Paper, Scissors!" << std::endl;
    std::cout << "Type Rock, Paper, or Scissors? " << std::endl;

    Player player;
    Player computer;

    std::string choice;
    std::cin >> choice;

    player.setChoice(choice);
    std::cout << "Your choice was; " << player.getChoice() << std::endl;
    
    computer.setChoice(computer.generateChoice());
    std::cout << "The computers choice was: " << computer.getChoice() << std::endl;
    
    std::cout << player.getWinner(player, computer) << std::endl;
    return 0;
};